package activities;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.thread.IThreadWorkerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class Activity1 {
    WebDriver driver;
    WebDriverWait wait;
    @BeforeTest
    public void setup() {
        // Set up Firefox driver
        WebDriverManager.firefoxdriver().setup();
        // Create a new instance of the Firefox driver
        driver = new FirefoxDriver();
        // Open the page
        driver.get("http://alchemy.hguy.co/orangehrm");

        // Find the input fields
        WebElement username = driver.findElement(By.xpath("//input[@name='txtUsername']"));
        username.sendKeys("orange");
        WebElement password = driver.findElement(By.xpath("//input[@name='txtPassword']"));
        password.sendKeys("orangepassword123");
        WebElement login = driver.findElement(By.xpath("//input[@name='Submit']"));
        login.click();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Initialize WebDriverWait with a timeout of 10 seconds

    }

    @Test (priority = 0)
    public void verifyUserLoggedIn(){
        // Find the element using its locator
        WebElement element = driver.findElement(By.xpath("//a//b[text()='Dashboard']"));
        // Verify if the element is present
        Assert.assertTrue(element.isDisplayed(), "Element is not present on the webpage");
        System.out.println("User successfully logged in");
    }
    @Test(priority = 1)
    public void verifyWebsiteTitle() {

        // Print the title of the page
        System.out.println("Home page title: " + driver.getTitle());
        String title = driver.getTitle();
        // Verify the title matches "OrangeHRM" exactly
        Assert.assertEquals(title, "OrangeHRM");
    }
    @Test(priority = 2)
    public void printWebsiteURL() {
        // Print the URL of the page
        System.out.println("URL is : " + driver.getCurrentUrl());

    }

    @Test(priority = 3)
    public void addNewEmployee() throws InterruptedException {
        WebElement linkPIM = driver.findElement(By.xpath("//a//b[text()='PIM']"));
        linkPIM.click();
        WebElement btnAdd = driver.findElement(By.xpath("//input[@id='btnAdd']"));
        btnAdd.click();
        WebElement txtFname = driver.findElement(By.xpath("//input[@id='firstName']"));
        txtFname.sendKeys("Emp1");
        WebElement txtLname = driver.findElement(By.xpath("//input[@id='lastName']"));
        txtLname.sendKeys("Emp1Lname");
        WebElement btnSave = driver.findElement(By.xpath("//input[@id='btnSave']"));
        btnSave.click();
    }
    @Test(priority = 4)
    public void verifyEmpAdded() throws InterruptedException {
//        Thread.sleep(10000);
        WebElement linkPIM = driver.findElement(By.xpath("//a//b[text()='PIM']"));
        linkPIM.click();
//        Thread.sleep(4000);
        String empName = "Emp1 Emp1Lname";
        WebElement txtSearchName = driver.findElement(By.xpath("//input[@name='empsearch[employee_name][empName]']"));
        txtSearchName.sendKeys(empName);
        Thread.sleep(2000);
        txtSearchName.sendKeys(Keys.TAB);
        WebElement btnSearch = driver.findElement(By.xpath("//input[@id='searchBtn']"));
        btnSearch.click();
        System.out.println("Employee name added successfully");
    }

    @Test(priority = 5)
    public void editEmpDetails() throws InterruptedException {
        WebElement linkMyInfo = driver.findElement(By.xpath("//a//b[text()='My Info']"));
        linkMyInfo.click();
        WebElement btnEdit = driver.findElement(By.xpath("//input[@id='btnSave']"));
        btnEdit.click();
        String empName = "Supriya";
        WebElement txtFName = driver.findElement(By.xpath("//input[@title='First Name']"));
        txtFName.clear();
        txtFName.sendKeys(empName);
        WebElement rdGender = driver.findElement(By.xpath("//input[@value=2][contains(@id,'personal_optGender')]"));
        rdGender.click();
        Select drpStatus = new Select(driver.findElement(By.xpath("//select[@id='personal_cmbMarital']")));
        drpStatus.selectByValue("Married");
        WebElement txtDOB = driver.findElement(By.xpath("//input[@id='personal_DOB']"));
        txtDOB.clear();
        txtDOB.sendKeys("1998-06-06");
        WebElement btnSave = driver.findElement(By.xpath("//input[@id='btnSave']"));
        btnSave.click();
        System.out.println("Employee name edited successfully");
    }

    @Test(priority = 6)
    public void verifyDirectoryMenu(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement lnkDirectory = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a//b[text() = 'Directory']")));
        lnkDirectory = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a//b[text() = 'Directory']")));
        lnkDirectory.click();
        String strHeader = driver.findElement(By.xpath("//h1[text() = 'Search Directory']")).getText();
        Assert.assertEquals(strHeader, "Search Directory");
        System.out.println("User clicked on Directory menu successfully");
    }

    @Test(priority = 7)
    public void addQualification(){
        WebElement linkMyInfo = driver.findElement(By.xpath("//a//b[text()='My Info']"));
        linkMyInfo.click();
        WebElement lnkQualifications = driver.findElement(By.xpath("(//li//a[text() = 'Qualifications'])[last()]"));
        lnkQualifications.click();
        WebElement btnAdd = driver.findElement(By.xpath("//input[@id = 'addWorkExperience']"));
        btnAdd.click();
        WebElement txtCompany = driver.findElement(By.xpath("//input[@id = 'experience_employer']"));
        txtCompany.sendKeys("abc company");
        WebElement txtJobTitle = driver.findElement(By.xpath("//input[@id = 'experience_jobtitle']"));
        txtJobTitle.sendKeys("Senior Consultant");
        WebElement btnSave = driver.findElement(By.xpath("//input[@id = 'btnWorkExpSave']"));
        btnSave.click();

    }

    @Test(priority = 8)
    public void applyLeave() throws InterruptedException {
        WebElement element = driver.findElement(By.xpath("//a//b[text()='Dashboard']"));
        element.click();
        Thread.sleep(4000);
        WebElement lnkApplyLeave = driver.findElement(By.xpath("(//a[contains(@href, 'applyLeave')])[last()]"));
        lnkApplyLeave.click();
        Select drpLType = new Select(driver.findElement(By.xpath("//select[@id='applyleave_txtLeaveType']")));
        drpLType.selectByValue("1");
        WebElement txtFromDt = driver.findElement(By.xpath("//input[@id='applyleave_txtFromDate']"));
        txtFromDt.clear();
        WebElement txtToDt = driver.findElement(By.xpath("//input[@id='applyleave_txtToDate']"));
        txtFromDt.sendKeys("2023-10-10");
        Thread.sleep(3000);
        txtToDt.clear();
        txtToDt.sendKeys("2023-10-12");
        WebElement btnApply = driver.findElement(By.xpath("//p//input[@id='applyBtn']"));
        btnApply.click();
        System.out.println("Leave applied successfully");
    }

    @Test(priority = 9)
    public void verifyLeaveStatus() throws InterruptedException {
        Thread.sleep(3000);
        WebElement lnkLeave = driver.findElement(By.xpath("//a[text()='My Leave']"));
        lnkLeave.click();
        WebElement txtFromDt = driver.findElement(By.xpath("//input[@id='calFromDate']"));
        txtFromDt.clear();
        txtFromDt.sendKeys("2023-10-10");
        txtFromDt.sendKeys(Keys.TAB);
        Thread.sleep(3000);
        WebElement txtToDt = driver.findElement(By.xpath("//input[@id='calToDate']"));
        txtToDt.clear();
        txtToDt.sendKeys("2023-10-12");
        txtToDt.sendKeys(Keys.TAB);
        WebElement btnSearch = driver.findElement(By.xpath("//input[@id='btnSearch']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", btnSearch);
//
//        btnSearch.click();
        Thread.sleep(3000);
        String strLeaveStatus = driver.findElement(By.xpath("(//a[contains(@href, 'viewLeaveRequest')])[2]")).getText();
        System.out.println("Leave status is "+strLeaveStatus);
    }

    @Test(priority = 10)
    public void retrieveEmergencyContacts(){
        List<String> lstContact = new ArrayList<String>();
        WebElement linkMyInfo = driver.findElement(By.xpath("//a//b[text()='My Info']"));
        linkMyInfo.click();
        WebElement linkEContact = driver.findElement(By.xpath("//a[text()='Emergency Contacts']"));
        linkEContact.click();
        int listSize = driver.findElements(By.xpath("//table[@id='emgcontact_list']//tr")).size();
        for(int i=1;i<listSize;i++){
            String xpath = "(//table[@id='emgcontact_list']//tr["+i+"])[last()]//td[5]";
            String strNumber = driver.findElement(By.xpath(xpath)).getText();
            lstContact.add(strNumber);
        }
        System.out.println("Emergency Contacts are: "+lstContact);
    }

    @AfterTest
    public void teardown() {
        // Close the browser
        driver.quit();
    }
}

