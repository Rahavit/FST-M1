import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys
@pytest.fixture(scope="module")
def driver():
    # Set up Firefox driver
    driver = webdriver.Firefox()
    # Open the page
    driver.get("http://alchemy.hguy.co/orangehrm")

    # Find the input fields
    username = driver.find_element(By.XPATH, "//input[@name='txtUsername']")
    username.send_keys("orange")
    password = driver.find_element(By.XPATH, "//input[@name='txtPassword']")
    password.send_keys("orangepassword123")
    login = driver.find_element(By.XPATH, "//input[@name='Submit']")
    login.click()

    yield driver

    # Teardown - close the browser
    driver.quit()

def test_user_logged_in(driver):
    # Find the element using its locator
    element = driver.find_element(By.XPATH, "//a//b[text()='Dashboard']")
    # Verify if the element is present
    assert element.is_displayed(), "Element is not present on the webpage"
    print("User successfully logged in")

def test_website_title(driver):
    # Print the title of the page
    print("Home page title:", driver.title)
    # Verify the title matches "OrangeHRM" exactly
    assert driver.title == "OrangeHRM"

def test_print_website_url(driver):
    # Print the URL of the page
    print("URL is:", driver.current_url)

def test_add_new_employee(driver):
    linkPIM = driver.find_element(By.XPATH, "//a//b[text()='PIM']")
    linkPIM.click()
    btnAdd = driver.find_element(By.XPATH, "//input[@id='btnAdd']")
    btnAdd.click()
    txtFname = driver.find_element(By.XPATH, "//input[@id='firstName']")
    txtFname.send_keys("Emp1")
    txtLname = driver.find_element(By.XPATH, "//input[@id='lastName']")
    txtLname.send_keys("Emp1Lname")
    btnSave = driver.find_element(By.XPATH, "//input[@id='btnSave']")
    btnSave.click()

def test_verify_emp_added(driver):
    linkPIM = driver.find_element(By.XPATH, "//a//b[text()='PIM']")
    linkPIM.click()
    empName = "Emp1 Emp1Lname"
    txtSearchName = driver.find_element(By.XPATH, "//input[@name='empsearch[employee_name][empName]']")
    txtSearchName.send_keys(empName)
    WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//input[@id='searchBtn']"))).click()
    print("Employee name added successfully")

def test_edit_emp_details(driver):
    linkMyInfo = driver.find_element(By.XPATH, "//a//b[text()='My Info']")
    linkMyInfo.click()
    btnEdit = driver.find_element(By.XPATH, "//input[@id='btnSave']")
    btnEdit.click()
    empName = "Supriya"
    txtFName = driver.find_element(By.XPATH, "//input[@title='First Name']")
    txtFName.clear()
    txtFName.send_keys(empName)
    rdGender = driver.find_element(By.XPATH, "//input[@value=2][contains(@id,'personal_optGender')]")
    rdGender.click()
    drpStatus = driver.find_element(By.XPATH, "//select[@id='personal_cmbMarital']")
    drpStatus.send_keys("Married")
    txtDOB = driver.find_element(By.XPATH, "//input[@id='personal_DOB']")
    txtDOB.clear()
    txtDOB.send_keys("1998-06-06")
    btnSave = driver.find_element(By.XPATH, "//input[@id='btnSave']")
    btnSave.click()
    print("Employee name edited successfully")

def test_verify_directory_menu(driver):
    wait = WebDriverWait(driver, 10)
    lnk_directory = wait.until(EC.visibility_of_element_located((By.XPATH, "//a//b[text() = 'Directory']")))
    lnk_directory = wait.until(EC.element_to_be_clickable((By.XPATH, "//a//b[text() = 'Directory']")))
    lnk_directory.click()
    str_header = driver.find_element(By.XPATH, "//h1[text() = 'Search Directory']").text
    assert str_header == "Search Directory"
    print("User clicked on Directory menu successfully")


def test_add_qualification(driver):
    link_my_info = driver.find_element(By.XPATH, "//a//b[text()='My Info']")
    link_my_info.click()
    lnk_qualifications = driver.find_element(By.XPATH, "(//li//a[text() = 'Qualifications'])[last()]")
    lnk_qualifications.click()
    btn_add = driver.find_element(By.XPATH, "//input[@id = 'addWorkExperience']")
    btn_add.click()
    txt_company = driver.find_element(By.XPATH, "//input[@id = 'experience_employer']")
    txt_company.send_keys("abc company")
    txt_job_title = driver.find_element(By.XPATH, "//input[@id = 'experience_jobtitle']")
    txt_job_title.send_keys("Senior Consultant")
    btn_save = driver.find_element(By.XPATH, "//input[@id = 'btnWorkExpSave']")
    btn_save.click()


def test_apply_leave(driver):
    element = driver.find_element(By.XPATH, "//a//b[text()='Dashboard']")
    element.click()
    lnk_apply_leave = driver.find_element(By.XPATH, "(//a[contains(@href, 'applyLeave')])[last()]")
    lnk_apply_leave.click()
    drp_l_type = Select(driver.find_element(By.XPATH, "//select[@id='applyleave_txtLeaveType']"))
    drp_l_type.select_by_value("1")
    txt_from_dt = driver.find_element(By.XPATH, "//input[@id='applyleave_txtFromDate']")
    txt_from_dt.clear()
    txt_to_dt = driver.find_element(By.XPATH, "//input[@id='applyleave_txtToDate']")
    txt_from_dt.send_keys("2023-10-10")
    txt_to_dt.clear()
    txt_to_dt.send_keys("2023-10-12")
    btn_apply = driver.find_element(By.XPATH, "//p//input[@id='applyBtn']")
    btn_apply.click()
    print("Leave applied successfully")


def test_verify_leave_status(driver):
    lnk_leave = driver.find_element(By.XPATH, "//a[text()='My Leave']")
    lnk_leave.click()
    txt_from_dt = driver.find_element(By.XPATH, "//input[@id='calFromDate']")
    txt_from_dt.clear()
    txt_from_dt.send_keys("2023-10-10")
    txt_from_dt.send_keys(Keys.TAB)
    txt_to_dt = driver.find_element(By.XPATH, "//input[@id='calToDate']")
    txt_to_dt.clear()
    txt_to_dt.send_keys("2023-10-12")
    txt_to_dt.send_keys(Keys.TAB)
    btn_search = driver.find_element(By.XPATH, "//input[@id='btnSearch']")
    btn_search.location_once_scrolled_into_view
    str_leave_status = driver.find_element(By.XPATH, "(//a[contains(@href, 'viewLeaveRequest')])[2]").text
    print("Leave status is " + str_leave_status)


def test_retrieve_emergency_contacts(driver):
    lst_contact = []
    link_my_info = driver.find_element(By.XPATH, "//a//b[text()='My Info']")
    link_my_info.click()
    link_e_contact = driver.find_element(By.XPATH, "//a[text()='Emergency Contacts']")
    link_e_contact.click()
    list_size = len(driver.find_elements(By.XPATH, "//table[@id='emgcontact_list']//tr"))
    for i in range(1, list_size):
        xpath = "(//table[@id='emgcontact_list']//tr[" + str(i) + "])[last()]//td[5]"
        str_number = driver.find_element(By.XPATH, xpath).text
        lst_contact.append(str_number)
    print("Emergency Contacts are: " + ", ".join(lst_contact))

    # Teardown - close the browser
    driver.quit()

# Run the tests
def main():
    pytest.main(["-v", "--driver=firefox"])


if __name__ == "__main__":
    main()
